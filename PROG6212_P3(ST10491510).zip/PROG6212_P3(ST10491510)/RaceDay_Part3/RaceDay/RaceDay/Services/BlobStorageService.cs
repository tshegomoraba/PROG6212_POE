using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Api.Services;

public interface IBlobStorageService
{
    Task<string> UploadAsync(IFormFile file, string folder, CancellationToken cancellationToken = default);
}

public sealed class BlobStorageService : IBlobStorageService
{
    private readonly BlobContainerClient _container;
    private readonly ILogger<BlobStorageService> _logger;
    private static readonly HashSet<string> AllowedTypes = new(StringComparer.OrdinalIgnoreCase)
    { "image/jpeg", "image/png", "image/webp" };

    public BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
    {
        _logger = logger;
        var connection = configuration["AzureBlobStorage:ConnectionString"];
        var containerName = configuration["AzureBlobStorage:ContainerName"] ?? "raceday-images";
        if (string.IsNullOrWhiteSpace(connection))
            throw new InvalidOperationException("AzureBlobStorage:ConnectionString is not configured.");
        _container = new BlobContainerClient(connection, containerName);
    }

    public async Task<string> UploadAsync(IFormFile file, string folder, CancellationToken cancellationToken = default)
    {
        if (file is null || file.Length == 0) throw new ArgumentException("Please select an image.");
        if (file.Length > 5 * 1024 * 1024) throw new ArgumentException("Images must be 5 MB or smaller.");
        if (!AllowedTypes.Contains(file.ContentType)) throw new ArgumentException("Only JPG, PNG, and WEBP images are allowed.");

        await _container.CreateIfNotExistsAsync(PublicAccessType.Blob, cancellationToken: cancellationToken);
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        var blobName = $"{folder.Trim('/')}/{Guid.NewGuid():N}{extension}";
        var blob = _container.GetBlobClient(blobName);
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, new BlobUploadOptions
        {
            HttpHeaders = new BlobHttpHeaders { ContentType = file.ContentType }
        }, cancellationToken);
        _logger.LogInformation("Uploaded image {BlobName}", blobName);
        return blob.Uri.ToString();
    }
}
