using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace RaceDay.Api.Data;

public class RaceDayDbContext : DbContext
{
    public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options) { }

    public DbSet<Role> Roles => Set<Role>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<RaceEvent> Events => Set<RaceEvent>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<RaceRoute> Routes => Set<RaceRoute>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<RaceResult> Results => Set<RaceResult>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Role>(e =>
        {
            e.ToTable("Roles");
            e.HasKey(x => x.RoleID);
            e.Property(x => x.RoleName).IsRequired().HasMaxLength(20).IsUnicode(false);
            e.HasIndex(x => x.RoleName).IsUnique();
            e.HasData(
                new Role { RoleID = 1, RoleName = "Admin" },
                new Role { RoleID = 2, RoleName = "Organiser" },
                new Role { RoleID = 3, RoleName = "Participant" });
        });

        modelBuilder.Entity<AppUser>(e =>
        {
            e.ToTable("Users");
            e.HasKey(x => x.UserID);
            e.Property(x => x.FullName).IsRequired().HasMaxLength(100).IsUnicode(false);
            e.Property(x => x.Email).IsRequired().HasMaxLength(100).IsUnicode(false);
            e.Property(x => x.PasswordHash).IsRequired().HasMaxLength(255).IsUnicode(false);
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.ProfileImageUrl).HasMaxLength(500).IsUnicode(false);
            e.Property(x => x.RegisteredDate).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.HasIndex(x => x.Email).IsUnique();
            e.HasOne(x => x.Role).WithMany(r => r.Users)
                .HasForeignKey(x => x.RoleID).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RaceEvent>(e =>
        {
            e.ToTable("Events", t => t.HasCheckConstraint("CK_Events_Type",
                "[EventType] IN ('Running','Cycling','Walking')"));
            e.HasKey(x => x.EventID);
            e.Property(x => x.EventName).IsRequired().HasMaxLength(150).IsUnicode(false);
            e.Property(x => x.EventType).IsRequired().HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.EventDate).HasColumnType("date");
            e.Property(x => x.DistanceKM).HasPrecision(5, 2);
            e.Property(x => x.Location).IsRequired().HasMaxLength(150).IsUnicode(false);
            e.Property(x => x.Latitude).HasPrecision(9, 6);
            e.Property(x => x.Longitude).HasPrecision(9, 6);
            e.Property(x => x.Description).HasMaxLength(500).IsUnicode(false);
            e.Property(x => x.BannerImageUrl).HasMaxLength(500).IsUnicode(false);
            e.Property(x => x.CreatedDate).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.HasOne(x => x.Organiser).WithMany(u => u.OrganisedEvents)
                .HasForeignKey(x => x.OrganiserID).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Category>(e =>
        {
            e.ToTable("Categories");
            e.HasKey(x => x.CategoryID);
            e.Property(x => x.CategoryName).IsRequired().HasMaxLength(100).IsUnicode(false);
            e.Property(x => x.DistanceKM).HasPrecision(5, 2);
            e.Property(x => x.MinAge).HasDefaultValue(0);
            e.Property(x => x.EntryFee).HasPrecision(8, 2).HasDefaultValue(0m);
            e.HasOne(x => x.Event).WithMany(ev => ev.Categories)
                .HasForeignKey(x => x.EventID).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RaceRoute>(e =>
        {
            e.ToTable("Routes");
            e.HasKey(x => x.RouteID);
            e.Property(x => x.RouteName).IsRequired().HasMaxLength(100).IsUnicode(false);
            e.Property(x => x.StartPoint).IsRequired().HasMaxLength(150).IsUnicode(false);
            e.Property(x => x.EndPoint).IsRequired().HasMaxLength(150).IsUnicode(false);
            e.Property(x => x.ElevationGainM).HasDefaultValue(0);
            e.Property(x => x.MapUrl).HasMaxLength(255).IsUnicode(false);
            e.Property(x => x.RouteNotes).HasMaxLength(500).IsUnicode(false);
            e.HasOne(x => x.Category).WithOne(c => c.Route)
                .HasForeignKey<RaceRoute>(x => x.CategoryID).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Enrolment>(e =>
        {
            e.ToTable("Enrolments", t => t.HasCheckConstraint("CK_Enrolments_Payment",
                "[PaymentStatus] IN ('Pending','Paid','Refunded')"));
            e.HasKey(x => x.EnrolmentID);
            e.Property(x => x.EnrolmentDate).HasColumnType("datetime").HasDefaultValueSql("GETDATE()");
            e.Property(x => x.BibNumber).IsRequired().HasMaxLength(10).IsUnicode(false);
            e.HasIndex(x => x.BibNumber).IsUnique();
            e.Property(x => x.PaymentStatus).IsRequired().HasMaxLength(20).IsUnicode(false).HasDefaultValue("Pending");
            e.HasOne(x => x.Participant).WithMany(u => u.Enrolments)
                .HasForeignKey(x => x.ParticipantID).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Category).WithMany(c => c.Enrolments)
                .HasForeignKey(x => x.CategoryID).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RaceResult>(e =>
        {
            e.ToTable("Results", t => t.HasCheckConstraint("CK_Results_Status",
                "[Status] IN ('Registered','Finished','DNF','DQ')"));
            e.HasKey(x => x.ResultID);
            e.Property(x => x.FinishTime).HasColumnType("time");
            e.Property(x => x.Status).IsRequired().HasMaxLength(20).IsUnicode(false).HasDefaultValue("Registered");
            e.HasOne(x => x.Enrolment).WithOne(en => en.Result)
                .HasForeignKey<RaceResult>(x => x.EnrolmentID).OnDelete(DeleteBehavior.Restrict);
        });
    }
}