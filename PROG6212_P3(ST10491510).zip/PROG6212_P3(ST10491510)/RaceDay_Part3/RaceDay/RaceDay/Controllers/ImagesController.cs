using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Security;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api")]
public class ImagesController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IBlobStorageService _blobs;
    public ImagesController(RaceDayDbContext db, IBlobStorageService blobs) { _db = db; _blobs = blobs; }

    [HttpPost("events/{id:int}/banner")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    public async Task<IActionResult> UploadBanner(int id, IFormFile file, CancellationToken cancellationToken)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == id, cancellationToken);
        if (ev is null) return NotFound(new { message = "Event not found." });
        if (ev.OrganiserID != CurrentUserId) return Forbidden("You can only change events that you created.");
        try { ev.BannerImageUrl = await _blobs.UploadAsync(file, "events", cancellationToken); await _db.SaveChangesAsync(cancellationToken); return Ok(ev.ToResponse()); }
        catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
    }

    [HttpPost("users/me/profile-picture")]
    [SessionAuthorize]
    public async Task<IActionResult> UploadProfilePicture(IFormFile file, CancellationToken cancellationToken)
    {
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.UserID == CurrentUserId, cancellationToken);
        if (user is null) return NotFound(new { message = "User not found." });
        try { user.ProfileImageUrl = await _blobs.UploadAsync(file, "profiles", cancellationToken); await _db.SaveChangesAsync(cancellationToken); return Ok(user.ToResponse()); }
        catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
    }
}
