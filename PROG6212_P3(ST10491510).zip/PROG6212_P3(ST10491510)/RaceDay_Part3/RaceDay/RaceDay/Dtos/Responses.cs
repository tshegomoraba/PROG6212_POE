﻿using RaceDay.Api.Models;
namespace RaceDay.Api.Dtos;
public record UserProfileResponse(int UserID, string FullName, string Email, string? PhoneNumber, string Role, DateTime RegisteredDate, string? ProfileImageUrl);
public record LoginResponse(int UserID, string FullName, string Role, string Message);
public record CategoryResponse(int CategoryID, int EventID, string CategoryName, decimal DistanceKM, int MinAge, decimal EntryFee);
public record EventResponse(int EventID, int OrganiserID, string EventName, string EventType, DateTime EventDate, decimal DistanceKM, string Location, decimal? Latitude, decimal? Longitude, string? Description, string? BannerImageUrl);
public record EventDetailResponse(int EventID, int OrganiserID, string EventName, string EventType, DateTime EventDate, decimal DistanceKM, string Location, decimal? Latitude, decimal? Longitude, string? Description, string? BannerImageUrl, List<CategoryResponse> Categories);
public record RouteResponse(int RouteID, int CategoryID, string RouteName, string StartPoint, string EndPoint, int ElevationGainM, string? MapUrl, string? RouteNotes);
public record EnrolmentResponse(int EnrolmentID, int ParticipantID, int CategoryID, string CategoryName, int EventID, string EventName, DateTime EnrolmentDate, string BibNumber, string PaymentStatus);
public record OrganiserEnrolmentResponse(int EnrolmentID, int ParticipantID, string ParticipantName, string ParticipantEmail, int CategoryID, string CategoryName, string BibNumber, string PaymentStatus, DateTime EnrolmentDate);
public record ResultResponse(int ResultID, int EnrolmentID, string BibNumber, string ParticipantName, TimeSpan? FinishTime, int? Position, string Status);
public record HistoryResponse(string EventName, DateTime EventDate, string CategoryName, TimeSpan? FinishTime, int? Position, string Status);
public record WeatherResponse(string EventName, string Location, DateTime EventDate, double? CurrentTemperatureC, double? CurrentWindSpeedKmh, double? ForecastMaxTempC, double? ForecastMinTempC, int? RainChancePercent, double? ForecastMaxWindKmh, string Note);
public static class Mappers
{
 public static UserProfileResponse ToResponse(this AppUser u) => new(u.UserID,u.FullName,u.Email,u.PhoneNumber,u.Role.RoleName,u.RegisteredDate,u.ProfileImageUrl);
 public static CategoryResponse ToResponse(this Category c) => new(c.CategoryID,c.EventID,c.CategoryName,c.DistanceKM,c.MinAge,c.EntryFee);
 public static EventResponse ToResponse(this RaceEvent e) => new(e.EventID,e.OrganiserID,e.EventName,e.EventType,e.EventDate,e.DistanceKM,e.Location,e.Latitude,e.Longitude,e.Description,e.BannerImageUrl);
 public static EventDetailResponse ToDetailResponse(this RaceEvent e) => new(e.EventID,e.OrganiserID,e.EventName,e.EventType,e.EventDate,e.DistanceKM,e.Location,e.Latitude,e.Longitude,e.Description,e.BannerImageUrl,e.Categories.OrderBy(c=>c.DistanceKM).Select(c=>c.ToResponse()).ToList());
 public static RouteResponse ToResponse(this RaceRoute r) => new(r.RouteID,r.CategoryID,r.RouteName,r.StartPoint,r.EndPoint,r.ElevationGainM,r.MapUrl,r.RouteNotes);
 public static EnrolmentResponse ToResponse(this Enrolment e) => new(e.EnrolmentID,e.ParticipantID,e.CategoryID,e.Category.CategoryName,e.Category.EventID,e.Category.Event.EventName,e.EnrolmentDate,e.BibNumber,e.PaymentStatus);
 public static OrganiserEnrolmentResponse ToOrganiserResponse(this Enrolment e) => new(e.EnrolmentID,e.ParticipantID,e.Participant.FullName,e.Participant.Email,e.CategoryID,e.Category.CategoryName,e.BibNumber,e.PaymentStatus,e.EnrolmentDate);
 public static ResultResponse ToResponse(this RaceResult r, Enrolment e) => new(r.ResultID,r.EnrolmentID,e.BibNumber,e.Participant.FullName,r.FinishTime,r.Position,r.Status);
 public static HistoryResponse ToHistoryResponse(this Enrolment e) => new(e.Category.Event.EventName,e.Category.Event.EventDate,e.Category.CategoryName,e.Result!.FinishTime,e.Result.Position,e.Result.Status);
}
