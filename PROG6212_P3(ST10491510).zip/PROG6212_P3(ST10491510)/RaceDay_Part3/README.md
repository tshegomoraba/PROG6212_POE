# RaceDay Part 3

This package contains the Part 2 API extended for Part 3 and a new ASP.NET Core MVC frontend. The MVC project has no database access: all data operations go through the API. The API owns Azure Blob Storage uploads.

## Projects

- `RaceDay/` - API and the preserved Part 2 tests/migrations.
- `RaceDay.Mvc/` - MVC web frontend.

## Manual setup

1. Install Visual Studio 2022 with ASP.NET and web development, .NET 8 SDK, SQL Server/LocalDB, and Docker Desktop if required.
2. Open `RaceDay/RaceDay.sln` for the API, or open both `.csproj` files in one solution.
3. In `RaceDay/appsettings.json`, change `ConnectionStrings:DefaultConnection` to your SQL Server database.
4. Create an Azure Storage account and a Blob container. Replace `AzureBlobStorage:ConnectionString` in `RaceDay/appsettings.json` with the storage connection string. Keep the container name `raceday-images` or change it consistently. The service creates the container and uploads public blobs. For production, use a private container plus SAS/CDN instead of public blob access.
5. From `RaceDay/`, run `dotnet restore` and `dotnet ef database update` (install the tool with `dotnet tool install --global dotnet-ef` if needed). This applies the existing Part 2 migration and `20261110205000_AddImageUrls`.
6. Start the API first: `dotnet run --project RaceDay/RaceDay.Api.csproj`. Note its HTTPS URL, for example `https://localhost:7137/`.
7. In `RaceDay.Mvc/appsettings.json`, set `ApiSettings:BaseUrl` to the API URL, including the final `/`.
8. Start the MVC site: `dotnet run --project RaceDay.Mvc/RaceDay.Mvc.csproj` and open the printed URL.

The API uses a server session cookie. The MVC app stores the API `Set-Cookie` value in its own session and forwards it on protected API calls. Do not replace this with direct SQL access in MVC.

## Local commands

```bash
dotnet restore RaceDay/RaceDay.Api.csproj
dotnet ef database update --project RaceDay/RaceDay.Api.csproj
dotnet run --project RaceDay/RaceDay.Api.csproj
dotnet run --project RaceDay.Mvc/RaceDay.Mvc.csproj
```

## Docker

Build and run the MVC container from `RaceDay.Mvc/`:

```bash
docker build -t raceday-mvc .
docker run --rm -p 8080:8080 \
  -e ApiSettings__BaseUrl=https://host.docker.internal:7137/ \
  raceday-mvc
```

When the API is also containerised, put both containers on the same Docker network and use the API service name, for example `http://raceday-api:8080/`. Do not use `localhost` from inside the MVC container because it means the MVC container itself.

The API Dockerfile is in `RaceDay/Dockerfile`. Run the API with environment variables such as:

```bash
docker build -t raceday-api RaceDay
docker run --rm -p 8080:8080 \
  -e ConnectionStrings__DefaultConnection='YOUR_SQL_CONNECTION' \
  -e AzureBlobStorage__ConnectionString='YOUR_AZURE_STORAGE_CONNECTION_STRING' \
  raceday-api
```

## User acceptance checks

- Register one Participant and one Organiser.
- Log in as Organiser, create an event, upload a banner, add categories, and inspect enrolments.
- Log in as Participant, filter events, enrol in a category, check My Enrolments, upload a profile picture, and view My Results.
- Log in as Organiser and enter a Finished result with `hh:mm:ss` and a position. Confirm it appears under Participant My Results.
- Test wrong-role URLs and confirm they redirect to Access denied.

## Troubleshooting

- 401/403 from the MVC: confirm the API URL is correct, the login succeeded, and the browser accepts cookies.
- TLS error in local development: use the API HTTP URL from its launch profile instead of HTTPS, or trust the .NET development certificate with `dotnet dev-certs https --trust`.
- SQL login error: update the connection string and confirm SQL Server is running.
- Azure upload error: check the connection string, container name, storage firewall, and blob public access policy.
- If EF says the model snapshot is stale, run `dotnet ef migrations add AddImageUrls --project RaceDay/RaceDay.Api.csproj` and then `dotnet ef database update`.
