using System.ComponentModel.DataAnnotations;
namespace RaceDay.Mvc.Models;
public record User(int UserID,string FullName,string Email,string? PhoneNumber,string Role,DateTime RegisteredDate,string? ProfileImageUrl);
public record Login(int UserID,string FullName,string Role,string Message);
public record Category(int CategoryID,int EventID,string CategoryName,decimal DistanceKM,int MinAge,decimal EntryFee);
public record Event(int EventID,int OrganiserID,string EventName,string EventType,DateTime EventDate,decimal DistanceKM,string Location,decimal? Latitude,decimal? Longitude,string? Description,string? BannerImageUrl);
public record EventDetail(int EventID,int OrganiserID,string EventName,string EventType,DateTime EventDate,decimal DistanceKM,string Location,decimal? Latitude,decimal? Longitude,string? Description,string? BannerImageUrl,List<Category> Categories);
public record Enrolment(int EnrolmentID,int ParticipantID,int CategoryID,string CategoryName,int EventID,string EventName,DateTime EnrolmentDate,string BibNumber,string PaymentStatus);
public record OrganiserEnrolment(int EnrolmentID,int ParticipantID,string ParticipantName,string ParticipantEmail,int CategoryID,string CategoryName,string BibNumber,string PaymentStatus,DateTime EnrolmentDate);
public record Result(int ResultID,int EnrolmentID,string BibNumber,string ParticipantName,TimeSpan? FinishTime,int? Position,string Status);
public record History(string EventName,DateTime EventDate,string CategoryName,TimeSpan? FinishTime,int? Position,string Status);
public class RegisterVm { [Required, StringLength(100)] public string FullName {get;set;}=""; [Required,EmailAddress] public string Email {get;set;}=""; [Required,MinLength(8)] public string Password {get;set;}=""; public string? PhoneNumber {get;set;} [Required] public string Role {get;set;}="Participant"; }
public class LoginVm { [Required,EmailAddress] public string Email {get;set;}=""; [Required] public string Password {get;set;}=""; }
public class EventVm { public int EventID {get;set;} [Required, StringLength(150)] public string EventName {get;set;}=""; [Required] public string EventType {get;set;}="Running"; [Required,DataType(DataType.Date)] public DateTime EventDate {get;set;}=DateTime.Today.AddDays(30); [Range(.01,999.99)] public decimal DistanceKM {get;set;}=10; [Required] public string Location {get;set;}=""; public decimal? Latitude {get;set;} public decimal? Longitude {get;set;} public string? Description {get;set;} public IFormFile? Banner {get;set;} }
public class CategoryVm { [Required] public string CategoryName {get;set;}=""; [Range(.01,999.99)] public decimal DistanceKM {get;set;} [Range(0,120)] public int MinAge {get;set;} [Range(0,100000)] public decimal EntryFee {get;set;} }
public class ResultVm { public TimeSpan? FinishTime {get;set;} public int? Position {get;set;} [Required] public string Status {get;set;}="Finished"; }
public class ProfileVm { [Required] public string FullName {get;set;}=""; public string? PhoneNumber {get;set;} public IFormFile? ProfilePicture {get;set;} }
public class DashboardVm { public List<Event> Events {get;set;}=new(); public Dictionary<int,int> EnrolmentCounts {get;set;}=new(); }
