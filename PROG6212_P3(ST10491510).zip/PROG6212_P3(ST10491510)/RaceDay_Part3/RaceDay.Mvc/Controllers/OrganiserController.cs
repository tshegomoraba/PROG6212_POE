using Microsoft.AspNetCore.Mvc; using RaceDay.Mvc.Models; using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[MvcAuthorize(RequiredRole="Organiser")]
public class OrganiserController:Controller { private readonly IRaceDayApiClient _api; public OrganiserController(IRaceDayApiClient a)=>_api=a;
 public async Task<IActionResult> Dashboard(){var ev=await _api.EventsAsync();var vm=new DashboardVm{Events=ev.Where(x=>x.OrganiserID==int.Parse(HttpContext.Session.GetString("UserId")!)).ToList()};foreach(var x in vm.Events)vm.EnrolmentCounts[x.EventID]=(await _api.EnrolmentsAsync(x.EventID)).Count;return View(vm);}
 public async Task<IActionResult> Events()=>View(await _api.EventsAsync());
 [HttpGet] public IActionResult CreateEvent()=>View(new EventVm());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> CreateEvent(EventVm m){if(!ModelState.IsValid)return View(m);var x=await _api.CreateEventAsync(m);if(x.Error is not null){ModelState.AddModelError("",x.Error);return View(m);}if(m.Banner is not null)await _api.UploadBannerAsync(x.Data!.EventID,m.Banner);TempData["Success"]="Event created.";return RedirectToAction(nameof(Events));}
 [HttpGet] public async Task<IActionResult> EditEvent(int id){var x=await _api.EventAsync(id);return x is null?NotFound():View(new EventVm{EventID=x.EventID,EventName=x.EventName,EventType=x.EventType,EventDate=x.EventDate,DistanceKM=x.DistanceKM,Location=x.Location,Latitude=x.Latitude,Longitude=x.Longitude,Description=x.Description});}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> EditEvent(EventVm m){if(!ModelState.IsValid)return View(m);var x=await _api.UpdateEventAsync(m.EventID,m);if(x.Error is not null){ModelState.AddModelError("",x.Error);return View(m);}if(m.Banner is not null)await _api.UploadBannerAsync(m.EventID,m.Banner);TempData["Success"]="Event updated.";return RedirectToAction(nameof(Events));}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> DeleteEvent(int id){var e=await _api.DeleteEventAsync(id);TempData[e is null?"Success":"Error"]=e??"Event deleted.";return RedirectToAction(nameof(Events));}
 public async Task<IActionResult> Manage(int id){var x=await _api.EventAsync(id);return x is null?NotFound():View(x);}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> AddCategory(int eventId,CategoryVm m){var e=await _api.AddCategoryAsync(eventId,m);TempData[e is null?"Success":"Error"]=e??"Category added.";return RedirectToAction(nameof(Manage),new{id=eventId});}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> DeleteCategory(int id,int eventId){var e=await _api.DeleteCategoryAsync(id);TempData[e is null?"Success":"Error"]=e??"Category deleted.";return RedirectToAction(nameof(Manage),new{id=eventId});}
 public async Task<IActionResult> Enrolments(int id)=>View(new Tuple<int,List<OrganiserEnrolment>>(id,await _api.EnrolmentsAsync(id)));
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> SaveResult(int eventId,int enrolmentId,ResultVm m){var e=await _api.SaveResultAsync(enrolmentId,m);TempData[e is null?"Success":"Error"]=e??"Result saved.";return RedirectToAction(nameof(Enrolments),new{id=eventId});}
}
