using Microsoft.AspNetCore.Mvc; using RaceDay.Mvc.Models; using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[MvcAuthorize(RequiredRole="Participant")]
public class ParticipantController:Controller { private readonly IRaceDayApiClient _api; public ParticipantController(IRaceDayApiClient a)=>_api=a;
 public async Task<IActionResult> Events(string? type)=>View("Events",await _api.EventsAsync(type));
 public async Task<IActionResult> Details(int id)=>View("Details",await _api.EventAsync(id));
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Enrol(int categoryId,int eventId){var e=await _api.EnrolAsync(categoryId);if(e is null)TempData["Success"]="You are enrolled successfully.";else TempData["Error"]=e;return RedirectToAction(nameof(Details),new{id=eventId});}
 public async Task<IActionResult> MyEnrolments()=>View(await _api.MyEnrolmentsAsync());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Cancel(int id){var e=await _api.CancelEnrolmentAsync(id);TempData[e is null?"Success":"Error"]=e??"Enrolment cancelled.";return RedirectToAction(nameof(MyEnrolments));}
 public async Task<IActionResult> MyResults()=>View(await _api.MyHistoryAsync());
 [HttpGet] public async Task<IActionResult> Profile(){var u=await _api.MeAsync();return View(new ProfileVm{FullName=u?.FullName??"",PhoneNumber=u?.PhoneNumber});}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Profile(ProfileVm m){if(!ModelState.IsValid)return View(m);var e=await _api.UpdateProfileAsync(m);if(e is null&&m.ProfilePicture is not null)e=await _api.UploadProfileAsync(m.ProfilePicture);TempData[e is null?"Success":"Error"]=e??"Profile updated.";return RedirectToAction(nameof(Profile));}
}
