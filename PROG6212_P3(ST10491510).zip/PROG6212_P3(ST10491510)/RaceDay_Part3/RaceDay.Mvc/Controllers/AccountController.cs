using Microsoft.AspNetCore.Mvc; using RaceDay.Mvc.Models; using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class AccountController:Controller { private readonly IRaceDayApiClient _api; public AccountController(IRaceDayApiClient a)=>_api=a;
 [HttpGet] public IActionResult Login(string? returnUrl=null)=>View(new LoginVm());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Login(LoginVm m,string? returnUrl=null){if(!ModelState.IsValid)return View(m);var x=await _api.LoginAsync(m);if(x.Error is not null){ModelState.AddModelError("",x.Error);return View(m);}HttpContext.Session.SetString("ApiCookie",x.Cookie??"");HttpContext.Session.SetString("Role",x.Data!.Role);HttpContext.Session.SetString("UserId",x.Data.UserID.ToString());HttpContext.Session.SetString("FullName",x.Data.FullName);return Redirect(string.IsNullOrWhiteSpace(returnUrl)?(x.Data.Role=="Organiser"?"/Organiser/Dashboard":"/Participant/Events"):returnUrl);}
 [HttpGet] public IActionResult Register()=>View(new RegisterVm());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Register(RegisterVm m){if(!ModelState.IsValid)return View(m);var e=await _api.RegisterAsync(m);if(e is not null){ModelState.AddModelError("",e);return View(m);}TempData["Success"]="Account created. Please log in.";return RedirectToAction(nameof(Login));}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Logout(){await _api.LogoutAsync();HttpContext.Session.Clear();return RedirectToAction("Index","Home");}
 public IActionResult AccessDenied()=>View();
}
