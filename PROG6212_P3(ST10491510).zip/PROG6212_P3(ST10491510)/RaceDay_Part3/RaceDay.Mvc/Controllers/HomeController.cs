using Microsoft.AspNetCore.Mvc; using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class HomeController:Controller { private readonly IRaceDayApiClient _api; public HomeController(IRaceDayApiClient a)=>_api=a; public async Task<IActionResult> Index(string? type){ViewBag.Type=type;return View(await _api.EventsAsync(type));} public async Task<IActionResult> Details(int id){var x=await _api.EventAsync(id);return x is null?NotFound():View(x);} public IActionResult Error()=>View(); }
