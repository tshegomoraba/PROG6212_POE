﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Api.Security;

/// <summary>The keys we use to store the logged-in user's details in the server-side session.</summary>
public static class SessionKeys
{
    public const string UserId = "UserId";
    public const string Role = "Role";
    public const string FullName = "FullName";
}

public static class RoleNames
{
    public const string Admin = "Admin";
    public const string Organiser = "Organiser";
    public const string Participant = "Participant";
}

/// <summary>
/// Put this on a controller or action to protect it.
/// No Roles value = any logged-in user. Roles = "Organiser" = organisers only.
/// Not logged in -> 401 Unauthorized. Logged in with the wrong role -> 403 Forbidden.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
{
    /// <summary>Comma separated list of roles allowed, for example "Organiser" or "Organiser,Participant".</summary>
    public string? Roles { get; set; }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        var session = context.HttpContext.Session;
        var userId = session.GetInt32(SessionKeys.UserId);

        if (userId is null)
        {
            context.Result = new UnauthorizedObjectResult(new { message = "You must log in to use this endpoint." });
            return;
        }

        if (!string.IsNullOrWhiteSpace(Roles))
        {
            var allowed = Roles.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var role = session.GetString(SessionKeys.Role);

            if (role is null || !allowed.Contains(role, StringComparer.OrdinalIgnoreCase))
            {
                context.Result = new ObjectResult(new { message = $"This endpoint is only available to: {string.Join(", ", allowed)}." })
                {
                    StatusCode = StatusCodes.Status403Forbidden
                };
            }
        }
    }
}