﻿namespace RaceDay.Api.Models;

// One class per table in the Part 1 ERD. Property names match the Part 1 column names.

public class Role
{
    public int RoleID { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public List<AppUser> Users { get; set; } = new();
}

public class AppUser
{
    public int UserID { get; set; }
    public int RoleID { get; set; }
    public Role Role { get; set; } = null!;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public DateTime RegisteredDate { get; set; }
    public List<RaceEvent> OrganisedEvents { get; set; } = new();
    public List<Enrolment> Enrolments { get; set; } = new();
}

public class RaceEvent
{
    public int EventID { get; set; }
    public int OrganiserID { get; set; }
    public AppUser Organiser { get; set; } = null!;
    public string EventName { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public DateTime EventDate { get; set; }
    public decimal DistanceKM { get; set; }
    public string Location { get; set; } = string.Empty;
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string? Description { get; set; }
    public DateTime CreatedDate { get; set; }
    public List<Category> Categories { get; set; } = new();
}

public class Category
{
    public int CategoryID { get; set; }
    public int EventID { get; set; }
    public RaceEvent Event { get; set; } = null!;
    public string CategoryName { get; set; } = string.Empty;
    public decimal DistanceKM { get; set; }
    public int MinAge { get; set; }
    public decimal EntryFee { get; set; }
    public RaceRoute? Route { get; set; }
    public List<Enrolment> Enrolments { get; set; } = new();
}

public class RaceRoute
{
    public int RouteID { get; set; }
    public int CategoryID { get; set; }
    public Category Category { get; set; } = null!;
    public string RouteName { get; set; } = string.Empty;
    public string StartPoint { get; set; } = string.Empty;
    public string EndPoint { get; set; } = string.Empty;
    public int ElevationGainM { get; set; }
    public string? MapUrl { get; set; }
    public string? RouteNotes { get; set; }
}

public class Enrolment
{
    public int EnrolmentID { get; set; }
    public int ParticipantID { get; set; }
    public AppUser Participant { get; set; } = null!;
    public int CategoryID { get; set; }
    public Category Category { get; set; } = null!;
    public DateTime EnrolmentDate { get; set; }
    public string BibNumber { get; set; } = string.Empty;
    public string PaymentStatus { get; set; } = "Pending";
    public RaceResult? Result { get; set; }
}

public class RaceResult
{
    public int ResultID { get; set; }
    public int EnrolmentID { get; set; }
    public Enrolment Enrolment { get; set; } = null!;
    public TimeSpan? FinishTime { get; set; }
    public int? Position { get; set; }
    public string Status { get; set; } = "Registered";
}