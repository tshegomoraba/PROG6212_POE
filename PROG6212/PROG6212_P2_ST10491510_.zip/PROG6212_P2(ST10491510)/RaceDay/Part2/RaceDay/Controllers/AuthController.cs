﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;

    public AuthController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>Register a new account as an Organiser or a Participant.</summary>
    /// <remarks>
    /// Body: fullName, email, password (minimum 8 characters), phoneNumber (optional) and role.
    /// Only the roles Organiser and Participant can be chosen - nobody can register themselves as Admin.
    /// The password is hashed with BCrypt before it is saved; the original password is never stored.
    /// </remarks>
    /// <response code="201">Account created. Returns the new profile (never the password).</response>
    /// <response code="400">A field is missing or invalid, or the role is not Organiser or Participant.</response>
    /// <response code="409">An account with this email already exists.</response>
    [HttpPost("register")]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        string? roleName = request.Role.Trim().ToLowerInvariant() switch
        {
            "organiser" => RoleNames.Organiser,
            "participant" => RoleNames.Participant,
            _ => null
        };

        if (roleName is null)
        {
            return BadRequest(new { message = "Role must be either 'Organiser' or 'Participant'." });
        }

        var email = request.Email.Trim().ToLowerInvariant();
        if (await _db.Users.AnyAsync(u => u.Email == email))
        {
            return Conflict(new { message = "An account with this email already exists." });
        }

        var role = await _db.Roles.SingleAsync(r => r.RoleName == roleName);

        var user = new AppUser
        {
            RoleID = role.RoleID,
            Role = role,
            FullName = request.FullName.Trim(),
            Email = email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            PhoneNumber = request.PhoneNumber?.Trim(),
            RegisteredDate = DateTime.Now
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return Created("/api/users/me", user.ToResponse());
    }

    /// <summary>Log in with email and password.</summary>
    /// <remarks>
    /// On success the server starts a session and remembers the user's ID and role.
    /// The browser (or Swagger) then sends the session cookie automatically with every later request.
    /// </remarks>
    /// <response code="200">Logged in. Returns the user's ID, name and role.</response>
    /// <response code="401">Email or password is wrong.</response>
    [HttpPost("login")]
    [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Email == email);

        if (user is null || !BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
        {
            return Unauthorized(new { message = "Invalid email or password." });
        }

        HttpContext.Session.Clear();
        HttpContext.Session.SetInt32(SessionKeys.UserId, user.UserID);
        HttpContext.Session.SetString(SessionKeys.Role, user.Role.RoleName);
        HttpContext.Session.SetString(SessionKeys.FullName, user.FullName);

        return Ok(new LoginResponse(user.UserID, user.FullName, user.Role.RoleName, "Login successful."));
    }

    /// <summary>Log out and end the current session.</summary>
    /// <response code="204">Session ended.</response>
    /// <response code="401">Nobody is logged in.</response>
    [HttpPost("logout")]
    [SessionAuthorize]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return NoContent();
    }
}