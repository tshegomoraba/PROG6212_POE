﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

/// <summary>Shared helpers for all controllers: who is logged in, and tidy error responses.</summary>
public abstract class RaceDayControllerBase : ControllerBase
{
    /// <summary>The UserID stored in the session at login (0 if nobody is logged in).</summary>
    protected int CurrentUserId => HttpContext.Session.GetInt32(SessionKeys.UserId) ?? 0;

    protected ObjectResult Forbidden(string message) =>
        StatusCode(StatusCodes.Status403Forbidden, new { message });
}