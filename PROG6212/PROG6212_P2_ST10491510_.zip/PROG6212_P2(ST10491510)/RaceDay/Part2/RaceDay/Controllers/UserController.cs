﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;

    public UsersController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>View your own profile.</summary>
    /// <response code="200">Your profile.</response>
    /// <response code="401">You are not logged in.</response>
    [HttpGet("me")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetMe()
    {
        var user = await _db.Users.AsNoTracking().Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.UserID == CurrentUserId);

        if (user is null)
        {
            return NotFound(new { message = "User not found." });
        }

        return Ok(user.ToResponse());
    }

    /// <summary>Update your own name and phone number.</summary>
    /// <remarks>Body: fullName and phoneNumber. Email and role cannot be changed here.</remarks>
    /// <response code="200">Returns the updated profile.</response>
    /// <response code="400">A field is invalid.</response>
    /// <response code="401">You are not logged in.</response>
    [HttpPut("me")]
    [SessionAuthorize]
    [ProducesResponseType(typeof(UserProfileResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateMe([FromBody] UpdateProfileRequest request)
    {
        var user = await _db.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.UserID == CurrentUserId);
        if (user is null)
        {
            return NotFound(new { message = "User not found." });
        }

        user.FullName = request.FullName.Trim();
        user.PhoneNumber = request.PhoneNumber?.Trim();
        await _db.SaveChangesAsync();

        HttpContext.Session.SetString(SessionKeys.FullName, user.FullName);
        return Ok(user.ToResponse());
    }

    /// <summary>List every event and category you are enrolled in (Participants only).</summary>
    /// <response code="200">Your enrolments, newest first.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not a Participant.</response>
    [HttpGet("me/enrolments")]
    [SessionAuthorize(Roles = RoleNames.Participant)]
    [ProducesResponseType(typeof(IEnumerable<EnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyEnrolments()
    {
        var enrolments = await _db.Enrolments.AsNoTracking()
            .Include(e => e.Category).ThenInclude(c => c.Event)
            .Where(e => e.ParticipantID == CurrentUserId)
            .OrderByDescending(e => e.EnrolmentDate)
            .ToListAsync();

        return Ok(enrolments.Select(e => e.ToResponse()));
    }

    /// <summary>View your personal performance history (Participants only).</summary>
    /// <remarks>Every race you have a result for: event, category, finish time, position and status.</remarks>
    /// <response code="200">Your results, most recent event first.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not a Participant.</response>
    [HttpGet("me/history")]
    [SessionAuthorize(Roles = RoleNames.Participant)]
    [ProducesResponseType(typeof(IEnumerable<HistoryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyHistory()
    {
        var enrolments = await _db.Enrolments.AsNoTracking()
            .Include(e => e.Category).ThenInclude(c => c.Event)
            .Include(e => e.Result)
            .Where(e => e.ParticipantID == CurrentUserId && e.Result != null)
            .ToListAsync();

        return Ok(enrolments
            .OrderByDescending(e => e.Category.Event.EventDate)
            .Select(e => e.ToHistoryResponse()));
    }
}