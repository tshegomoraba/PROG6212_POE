﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/enrolments")]
public class EnrolmentsController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;

    public EnrolmentsController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>Cancel one of your own enrolments (Participants only).</summary>
    /// <remarks>An enrolment that already has a result recorded cannot be cancelled.</remarks>
    /// <response code="204">Enrolment cancelled.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not a Participant, or this enrolment belongs to someone else.</response>
    /// <response code="404">No enrolment with that ID.</response>
    /// <response code="409">A result has already been recorded for this enrolment.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(Roles = RoleNames.Participant)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> CancelEnrolment(int id)
    {
        var enrolment = await _db.Enrolments.Include(e => e.Result).FirstOrDefaultAsync(e => e.EnrolmentID == id);
        if (enrolment is null)
        {
            return NotFound(new { message = "Enrolment not found." });
        }
        if (enrolment.ParticipantID != CurrentUserId)
        {
            return Forbidden("You can only cancel your own enrolments.");
        }
        if (enrolment.Result is not null)
        {
            return Conflict(new { message = "A result has already been recorded, so this enrolment cannot be cancelled." });
        }

        _db.Enrolments.Remove(enrolment);
        await _db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Record or update a participant's finish time and position (Organisers only).</summary>
    /// <remarks>
    /// Body: finishTime (hh:mm:ss), position and status (Registered, Finished, DNF or DQ).
    /// When the status is Finished, both finishTime and position are required.
    /// Only the organiser who owns the event can record its results.
    /// </remarks>
    /// <response code="200">Result saved.</response>
    /// <response code="400">A field is invalid, or a Finished result is missing its time or position.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or the event belongs to another organiser.</response>
    /// <response code="404">No enrolment with that ID.</response>
    [HttpPost("{id:int}/results")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(ResultResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> SaveResult(int id, [FromBody] ResultRequest request)
    {
        var enrolment = await _db.Enrolments
            .Include(e => e.Participant)
            .Include(e => e.Category).ThenInclude(c => c.Event)
            .Include(e => e.Result)
            .FirstOrDefaultAsync(e => e.EnrolmentID == id);

        if (enrolment is null)
        {
            return NotFound(new { message = "Enrolment not found." });
        }
        if (enrolment.Category.Event.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only record results for events that you created.");
        }
        if (request.Status == "Finished" && (request.FinishTime is null || request.Position is null))
        {
            return BadRequest(new { message = "A Finished result needs both a finishTime and a position." });
        }

        var result = enrolment.Result;
        if (result is null)
        {
            result = new RaceResult { EnrolmentID = enrolment.EnrolmentID };
            _db.Results.Add(result);
        }

        result.FinishTime = request.FinishTime;
        result.Position = request.Position;
        result.Status = request.Status;
        await _db.SaveChangesAsync();

        return Ok(result.ToResponse(enrolment));
    }
}