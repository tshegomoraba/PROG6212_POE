﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly IWeatherService _weather;

    public EventsController(RaceDayDbContext db, IWeatherService weather)
    {
        _db = db;
        _weather = weather;
    }

    /// <summary>List upcoming events (public).</summary>
    /// <remarks>Optional query strings: type (Running, Cycling or Walking) and fromDate (defaults to today).</remarks>
    /// <response code="200">Events ordered by date.</response>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetEvents([FromQuery] string? type, [FromQuery] DateTime? fromDate)
    {
        var start = (fromDate ?? DateTime.Today).Date;
        var query = _db.Events.AsNoTracking().Where(e => e.EventDate >= start);

        if (!string.IsNullOrWhiteSpace(type))
        {
            var eventType = type.Trim();
            query = query.Where(e => e.EventType == eventType);
        }

        var events = await query.OrderBy(e => e.EventDate).ToListAsync();
        return Ok(events.Select(e => e.ToResponse()));
    }

    /// <summary>View one event with its categories (public).</summary>
    /// <response code="200">The event and its categories.</response>
    /// <response code="404">No event with that ID.</response>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(EventDetailResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventById(int id)
    {
        var ev = await _db.Events.AsNoTracking().Include(e => e.Categories)
            .FirstOrDefaultAsync(e => e.EventID == id);

        if (ev is null)
        {
            return NotFound(new { message = "Event not found." });
        }

        return Ok(ev.ToDetailResponse());
    }

    /// <summary>Create a new event (Organisers only).</summary>
    /// <remarks>
    /// Body: eventName, eventType (Running, Cycling or Walking), eventDate, distanceKM, location,
    /// description, and optionally latitude and longitude (needed for the weather endpoint).
    /// The event is automatically owned by the logged-in organiser.
    /// </remarks>
    /// <response code="201">Event created.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser.</response>
    [HttpPost]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> CreateEvent([FromBody] EventRequest request)
    {
        var ev = new RaceEvent
        {
            OrganiserID = CurrentUserId,
            CreatedDate = DateTime.Now
        };
        Apply(ev, request);

        _db.Events.Add(ev);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetEventById), new { id = ev.EventID }, ev.ToResponse());
    }

    /// <summary>Update an event you own (Organisers only).</summary>
    /// <response code="200">Event updated.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or this event belongs to another organiser.</response>
    /// <response code="404">No event with that ID.</response>
    [HttpPut("{id:int}")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEvent(int id, [FromBody] EventRequest request)
    {
        var ev = await _db.Events.FirstOrDefaultAsync(e => e.EventID == id);
        if (ev is null)
        {
            return NotFound(new { message = "Event not found." });
        }
        if (ev.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only change events that you created.");
        }

        Apply(ev, request);
        await _db.SaveChangesAsync();
        return Ok(ev.ToResponse());
    }

    /// <summary>Delete an event you own (Organisers only).</summary>
    /// <remarks>The event's categories and routes are deleted with it. Events that already have enrolments cannot be deleted.</remarks>
    /// <response code="204">Event deleted.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or this event belongs to another organiser.</response>
    /// <response code="404">No event with that ID.</response>
    /// <response code="409">The event already has enrolments.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var ev = await _db.Events
            .Include(e => e.Categories).ThenInclude(c => c.Route)
            .FirstOrDefaultAsync(e => e.EventID == id);

        if (ev is null)
        {
            return NotFound(new { message = "Event not found." });
        }
        if (ev.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only delete events that you created.");
        }

        var categoryIds = ev.Categories.Select(c => c.CategoryID).ToList();
        if (await _db.Enrolments.AnyAsync(en => categoryIds.Contains(en.CategoryID)))
        {
            return Conflict(new { message = "This event already has enrolments and cannot be deleted." });
        }

        foreach (var category in ev.Categories)
        {
            if (category.Route is not null)
            {
                _db.Routes.Remove(category.Route);
            }
        }
        _db.Categories.RemoveRange(ev.Categories);
        _db.Events.Remove(ev);
        await _db.SaveChangesAsync();

        return NoContent();
    }

    /// <summary>Get live weather for the event's location (public).</summary>
    /// <remarks>Uses the event's latitude and longitude to call an external weather service. Nothing is stored.</remarks>
    /// <response code="200">Forecast for the event date (or current conditions if the date is too far away).</response>
    /// <response code="400">The event has no coordinates.</response>
    /// <response code="404">No event with that ID.</response>
    /// <response code="502">The weather provider is unavailable.</response>
    [HttpGet("{id:int}/weather")]
    [ProducesResponseType(typeof(WeatherResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status502BadGateway)]
    public async Task<IActionResult> GetWeather(int id, CancellationToken cancellationToken)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventID == id, cancellationToken);
        if (ev is null)
        {
            return NotFound(new { message = "Event not found." });
        }
        if (ev.Latitude is null || ev.Longitude is null)
        {
            return BadRequest(new { message = "This event has no coordinates, so weather cannot be looked up." });
        }

        var data = await _weather.GetForecastAsync(ev.Latitude.Value, ev.Longitude.Value, ev.EventDate, cancellationToken);
        if (data is null)
        {
            return StatusCode(StatusCodes.Status502BadGateway, new { message = "The weather provider is currently unavailable." });
        }

        var note = data.ForecastAvailable
            ? "Forecast for the event date."
            : "A daily forecast is not available for the event date yet. Showing current conditions at the venue instead.";

        return Ok(new WeatherResponse(ev.EventName, ev.Location, ev.EventDate, data.CurrentTemperatureC,
            data.CurrentWindSpeedKmh, data.ForecastMaxTempC, data.ForecastMinTempC, data.RainChancePercent,
            data.ForecastMaxWindKmh, note));
    }

    /// <summary>List the categories of an event (public).</summary>
    /// <response code="200">The event's categories.</response>
    /// <response code="404">No event with that ID.</response>
    [HttpGet("{id:int}/categories")]
    [ProducesResponseType(typeof(IEnumerable<CategoryResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCategories(int id)
    {
        if (!await _db.Events.AnyAsync(e => e.EventID == id))
        {
            return NotFound(new { message = "Event not found." });
        }

        var categories = await _db.Categories.AsNoTracking()
            .Where(c => c.EventID == id)
            .OrderBy(c => c.DistanceKM)
            .ToListAsync();

        return Ok(categories.Select(c => c.ToResponse()));
    }

    /// <summary>Add an age or distance category to an event you own (Organisers only).</summary>
    /// <remarks>Body: categoryName (for example 10km or Under 20), distanceKM, minAge and entryFee.</remarks>
    /// <response code="201">Category created.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or this event belongs to another organiser.</response>
    /// <response code="404">No event with that ID.</response>
    [HttpPost("{id:int}/categories")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> AddCategory(int id, [FromBody] CategoryRequest request)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventID == id);
        if (ev is null)
        {
            return NotFound(new { message = "Event not found." });
        }
        if (ev.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only add categories to events that you created.");
        }

        var category = new Category
        {
            EventID = id,
            CategoryName = request.CategoryName.Trim(),
            DistanceKM = request.DistanceKM,
            MinAge = request.MinAge,
            EntryFee = request.EntryFee
        };

        _db.Categories.Add(category);
        await _db.SaveChangesAsync();

        return Created($"/api/events/{id}/categories", category.ToResponse());
    }

    /// <summary>List all enrolments for an event you own (Organisers only).</summary>
    /// <response code="200">Every participant enrolled, with category, bib number and payment status.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or this event belongs to another organiser.</response>
    /// <response code="404">No event with that ID.</response>
    [HttpGet("{id:int}/enrolments")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(IEnumerable<OrganiserEnrolmentResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEventEnrolments(int id)
    {
        var ev = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.EventID == id);
        if (ev is null)
        {
            return NotFound(new { message = "Event not found." });
        }
        if (ev.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only view enrolments for events that you created.");
        }

        var enrolments = await _db.Enrolments.AsNoTracking()
            .Include(e => e.Participant)
            .Include(e => e.Category)
            .Where(e => e.Category.EventID == id)
            .OrderBy(e => e.EnrolmentDate)
            .ToListAsync();

        return Ok(enrolments.Select(e => e.ToOrganiserResponse()));
    }

    private static void Apply(RaceEvent ev, EventRequest request)
    {
        ev.EventName = request.EventName.Trim();
        ev.EventType = request.EventType;
        ev.EventDate = request.EventDate!.Value.Date;
        ev.DistanceKM = request.DistanceKM;
        ev.Location = request.Location.Trim();
        ev.Latitude = request.Latitude;
        ev.Longitude = request.Longitude;
        ev.Description = request.Description?.Trim();
    }
}