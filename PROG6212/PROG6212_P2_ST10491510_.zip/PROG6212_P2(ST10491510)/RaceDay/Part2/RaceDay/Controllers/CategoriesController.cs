﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;
using RaceDay.Api.Security;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/categories")]
public class CategoriesController : RaceDayControllerBase
{
    private readonly RaceDayDbContext _db;

    public CategoriesController(RaceDayDbContext db)
    {
        _db = db;
    }

    /// <summary>Update a category on an event you own (Organisers only).</summary>
    /// <response code="200">Category updated.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or the event belongs to another organiser.</response>
    /// <response code="404">No category with that ID.</response>
    [HttpPut("{id:int}")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(CategoryResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateCategory(int id, [FromBody] CategoryRequest request)
    {
        var category = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category is null)
        {
            return NotFound(new { message = "Category not found." });
        }
        if (category.Event.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only change categories on events that you created.");
        }

        category.CategoryName = request.CategoryName.Trim();
        category.DistanceKM = request.DistanceKM;
        category.MinAge = request.MinAge;
        category.EntryFee = request.EntryFee;
        await _db.SaveChangesAsync();

        return Ok(category.ToResponse());
    }

    /// <summary>Delete a category from an event you own (Organisers only).</summary>
    /// <remarks>The category's route is deleted with it. Categories that already have enrolments cannot be deleted.</remarks>
    /// <response code="204">Category deleted.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or the event belongs to another organiser.</response>
    /// <response code="404">No category with that ID.</response>
    /// <response code="409">The category already has enrolments.</response>
    [HttpDelete("{id:int}")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var category = await _db.Categories.Include(c => c.Event).Include(c => c.Route)
            .FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category is null)
        {
            return NotFound(new { message = "Category not found." });
        }
        if (category.Event.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only delete categories on events that you created.");
        }
        if (await _db.Enrolments.AnyAsync(e => e.CategoryID == id))
        {
            return Conflict(new { message = "This category already has enrolments and cannot be deleted." });
        }

        if (category.Route is not null)
        {
            _db.Routes.Remove(category.Route);
        }
        _db.Categories.Remove(category);
        await _db.SaveChangesAsync();

        return NoContent();
    }

    /// <summary>View the route (start, end, elevation, map link) of a category (public).</summary>
    /// <response code="200">The route details.</response>
    /// <response code="404">No route has been set for this category.</response>
    [HttpGet("{id:int}/route")]
    [ProducesResponseType(typeof(RouteResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetRoute(int id)
    {
        var route = await _db.Routes.AsNoTracking().FirstOrDefaultAsync(r => r.CategoryID == id);
        if (route is null)
        {
            return NotFound(new { message = "No route has been set for this category." });
        }

        return Ok(route.ToResponse());
    }

    /// <summary>Create or replace the route of a category you own (Organisers only).</summary>
    /// <remarks>Body: routeName, startPoint, endPoint, elevationGainM, mapUrl and routeNotes.</remarks>
    /// <response code="201">Route saved.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not an Organiser, or the event belongs to another organiser.</response>
    /// <response code="404">No category with that ID.</response>
    [HttpPost("{id:int}/route")]
    [SessionAuthorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(RouteResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> SaveRoute(int id, [FromBody] RouteRequest request)
    {
        var category = await _db.Categories.Include(c => c.Event).Include(c => c.Route)
            .FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category is null)
        {
            return NotFound(new { message = "Category not found." });
        }
        if (category.Event.OrganiserID != CurrentUserId)
        {
            return Forbidden("You can only set routes on events that you created.");
        }

        var route = category.Route;
        if (route is null)
        {
            route = new RaceRoute { CategoryID = category.CategoryID };
            _db.Routes.Add(route);
        }

        route.RouteName = request.RouteName.Trim();
        route.StartPoint = request.StartPoint.Trim();
        route.EndPoint = request.EndPoint.Trim();
        route.ElevationGainM = request.ElevationGainM;
        route.MapUrl = request.MapUrl?.Trim();
        route.RouteNotes = request.RouteNotes?.Trim();
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, route.ToResponse());
    }

    /// <summary>Enter an event by choosing a category (Participants only).</summary>
    /// <remarks>
    /// No body is needed - the participant is identified from the session.
    /// The system records the link between the participant, the event and the category, and generates a bib number.
    /// A participant can only enter each event once.
    /// </remarks>
    /// <response code="201">Enrolled. Returns the enrolment with its bib number.</response>
    /// <response code="401">You are not logged in.</response>
    /// <response code="403">You are not a Participant.</response>
    /// <response code="404">No category with that ID.</response>
    /// <response code="409">You are already enrolled in this event.</response>
    [HttpPost("{id:int}/enrol")]
    [SessionAuthorize(Roles = RoleNames.Participant)]
    [ProducesResponseType(typeof(EnrolmentResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Enrol(int id)
    {
        var category = await _db.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryID == id);
        if (category is null)
        {
            return NotFound(new { message = "Category not found." });
        }

        var userId = CurrentUserId;
        var alreadyEnrolled = await _db.Enrolments
            .AnyAsync(e => e.ParticipantID == userId && e.Category.EventID == category.EventID);
        if (alreadyEnrolled)
        {
            return Conflict(new { message = "You are already enrolled in this event." });
        }

        var next = (await _db.Enrolments.MaxAsync(e => (int?)e.EnrolmentID) ?? 0) + 1;

        var enrolment = new Enrolment
        {
            ParticipantID = userId,
            CategoryID = category.CategoryID,
            Category = category,
            EnrolmentDate = DateTime.Now,
            BibNumber = $"B{1000 + next}",
            PaymentStatus = "Pending"
        };

        _db.Enrolments.Add(enrolment);
        await _db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, enrolment.ToResponse());
    }

    /// <summary>View the results (leaderboard) of a category (public).</summary>
    /// <response code="200">Results ordered by finishing position.</response>
    /// <response code="404">No category with that ID.</response>
    [HttpGet("{id:int}/results")]
    [ProducesResponseType(typeof(IEnumerable<ResultResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetResults(int id)
    {
        if (!await _db.Categories.AnyAsync(c => c.CategoryID == id))
        {
            return NotFound(new { message = "Category not found." });
        }

        var results = await _db.Results.AsNoTracking()
            .Include(r => r.Enrolment).ThenInclude(e => e.Participant)
            .Where(r => r.Enrolment.CategoryID == id)
            .ToListAsync();

        return Ok(results
            .OrderBy(r => r.Position ?? int.MaxValue)
            .ThenBy(r => r.FinishTime ?? TimeSpan.MaxValue)
            .Select(r => r.ToResponse(r.Enrolment)));
    }
}