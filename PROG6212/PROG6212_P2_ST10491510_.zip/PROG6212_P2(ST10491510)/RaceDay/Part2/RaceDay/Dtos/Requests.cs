﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Dtos;

// DTOs ("data transfer objects") describe exactly what JSON the API accepts.
// The validation attributes make ASP.NET return 400 Bad Request automatically for bad input.

public class RegisterRequest
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = string.Empty;

    [Required, EmailAddress, StringLength(100)]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(100, MinimumLength = 8)]
    public string Password { get; set; } = string.Empty;

    [StringLength(20)]
    public string? PhoneNumber { get; set; }

    /// <summary>Either Organiser or Participant.</summary>
    [Required]
    public string Role { get; set; } = string.Empty;
}

public class LoginRequest
{
    [Required]
    public string Email { get; set; } = string.Empty;

    [Required]
    public string Password { get; set; } = string.Empty;
}

public class UpdateProfileRequest
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = string.Empty;

    [StringLength(20)]
    public string? PhoneNumber { get; set; }
}

public class EventRequest
{
    [Required, StringLength(150)]
    public string EventName { get; set; } = string.Empty;

    /// <summary>Running, Cycling or Walking.</summary>
    [Required, RegularExpression("^(Running|Cycling|Walking)$", ErrorMessage = "EventType must be Running, Cycling or Walking.")]
    public string EventType { get; set; } = string.Empty;

    [Required]
    public DateTime? EventDate { get; set; }

    /// <summary>Headline distance of the event in kilometres.</summary>
    [Range(0.01, 999.99)]
    public decimal DistanceKM { get; set; }

    [Required, StringLength(150)]
    public string Location { get; set; } = string.Empty;

    [Range(-90, 90)]
    public decimal? Latitude { get; set; }

    [Range(-180, 180)]
    public decimal? Longitude { get; set; }

    [StringLength(500)]
    public string? Description { get; set; }
}

public class CategoryRequest
{
    [Required, StringLength(100)]
    public string CategoryName { get; set; } = string.Empty;

    [Range(0.01, 999.99)]
    public decimal DistanceKM { get; set; }

    [Range(0, 120)]
    public int MinAge { get; set; }

    [Range(0, 100000)]
    public decimal EntryFee { get; set; }
}

public class RouteRequest
{
    [Required, StringLength(100)]
    public string RouteName { get; set; } = string.Empty;

    [Required, StringLength(150)]
    public string StartPoint { get; set; } = string.Empty;

    [Required, StringLength(150)]
    public string EndPoint { get; set; } = string.Empty;

    [Range(0, 10000)]
    public int ElevationGainM { get; set; }

    [StringLength(255)]
    public string? MapUrl { get; set; }

    [StringLength(500)]
    public string? RouteNotes { get; set; }
}

public class ResultRequest
{
    /// <summary>Finish time as hh:mm:ss, for example 01:45:32.</summary>
    public TimeSpan? FinishTime { get; set; }

    [Range(1, 1000000)]
    public int? Position { get; set; }

    /// <summary>Registered, Finished, DNF or DQ.</summary>
    [Required, RegularExpression("^(Registered|Finished|DNF|DQ)$", ErrorMessage = "Status must be Registered, Finished, DNF or DQ.")]
    public string Status { get; set; } = string.Empty;
}