﻿using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace RaceDay.Api.Services;

public record WeatherData(double? CurrentTemperatureC, double? CurrentWindSpeedKmh, double? ForecastMaxTempC,
    double? ForecastMinTempC, int? RainChancePercent, double? ForecastMaxWindKmh, bool ForecastAvailable);

public interface IWeatherService
{
    /// <summary>Returns live weather for a location, or null if the weather provider could not be reached.</summary>
    Task<WeatherData?> GetForecastAsync(decimal latitude, decimal longitude, DateTime date, CancellationToken cancellationToken = default);
}

/// <summary>Calls the free Open-Meteo weather API (no API key needed).</summary>
public class WeatherService : IWeatherService
{
    private readonly HttpClient _http;

    public WeatherService(HttpClient http)
    {
        _http = http;
    }

    public async Task<WeatherData?> GetForecastAsync(decimal latitude, decimal longitude, DateTime date, CancellationToken cancellationToken = default)
    {
        var lat = latitude.ToString(CultureInfo.InvariantCulture);
        var lon = longitude.ToString(CultureInfo.InvariantCulture);
        var url = "https://api.open-meteo.com/v1/forecast"
                  + $"?latitude={lat}&longitude={lon}"
                  + "&current=temperature_2m,wind_speed_10m"
                  + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max"
                  + "&forecast_days=16&timezone=auto";

        try
        {
            using var response = await _http.GetAsync(url, cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var data = await response.Content.ReadFromJsonAsync<OpenMeteoResponse>(cancellationToken: cancellationToken);
            if (data is null)
            {
                return null;
            }

            var key = date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            var index = data.Daily?.Time?.IndexOf(key) ?? -1;
            var forecastAvailable = index >= 0;

            var rain = forecastAvailable ? ValueAt(data.Daily!.RainChance, index) : null;
            int? rainChance = rain is null ? null : (int)Math.Round(rain.Value);

            return new WeatherData(
                data.Current?.Temperature,
                data.Current?.WindSpeed,
                forecastAvailable ? ValueAt(data.Daily!.MaxTemp, index) : null,
                forecastAvailable ? ValueAt(data.Daily!.MinTemp, index) : null,
                rainChance,
                forecastAvailable ? ValueAt(data.Daily!.MaxWind, index) : null,
                forecastAvailable);
        }
        catch (HttpRequestException)
        {
            return null;
        }
        catch (TaskCanceledException)
        {
            return null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static T? ValueAt<T>(List<T?>? list, int index) where T : struct
    {
        if (list is null || index < 0 || index >= list.Count)
        {
            return null;
        }
        return list[index];
    }

    // Shapes of the JSON that Open-Meteo sends back.
    private class OpenMeteoResponse
    {
        [JsonPropertyName("current")] public CurrentBlock? Current { get; set; }
        [JsonPropertyName("daily")] public DailyBlock? Daily { get; set; }
    }

    private class CurrentBlock
    {
        [JsonPropertyName("temperature_2m")] public double? Temperature { get; set; }
        [JsonPropertyName("wind_speed_10m")] public double? WindSpeed { get; set; }
    }

    private class DailyBlock
    {
        [JsonPropertyName("time")] public List<string>? Time { get; set; }
        [JsonPropertyName("temperature_2m_max")] public List<double?>? MaxTemp { get; set; }
        [JsonPropertyName("temperature_2m_min")] public List<double?>? MinTemp { get; set; }
        [JsonPropertyName("precipitation_probability_max")] public List<double?>? RainChance { get; set; }
        [JsonPropertyName("wind_speed_10m_max")] public List<double?>? MaxWind { get; set; }
    }
}