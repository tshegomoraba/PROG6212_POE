﻿using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

public class EnrolmentTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public EnrolmentTests(RaceDayFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task Participant_CanEnrol_AndGetsABibNumber()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);

        var response = await participant.PostAsync($"/api/categories/{category.CategoryID}/enrol", null);

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var enrolment = await response.Content.ReadFromJsonAsync<EnrolmentResponse>();
        Assert.False(string.IsNullOrWhiteSpace(enrolment!.BibNumber));
        Assert.Equal(category.CategoryID, enrolment.CategoryID);
        Assert.Equal(ev.EventID, enrolment.EventID);
    }

    [Fact]
    public async Task Enrolment_IsRecordedAgainstParticipantEventAndCategory()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);

        var mine = await participant.GetAsync("/api/users/me/enrolments");

        Assert.Equal(HttpStatusCode.OK, mine.StatusCode);
        var list = await mine.Content.ReadFromJsonAsync<List<EnrolmentResponse>>();
        var saved = Assert.Single(list!);
        Assert.Equal(enrolment.EnrolmentID, saved.EnrolmentID);
        Assert.Equal(ev.EventID, saved.EventID);
        Assert.Equal(category.CategoryID, saved.CategoryID);
    }

    [Fact]
    public async Task Organiser_CanViewAllEnrolmentsForTheirEvent()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var first = await _factory.LoggedInClientAsync("Participant");
        var second = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        await TestSupport.EnrolAsync(first, category.CategoryID);
        await TestSupport.EnrolAsync(second, category.CategoryID);

        var response = await organiser.GetAsync($"/api/events/{ev.EventID}/enrolments");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var list = await response.Content.ReadFromJsonAsync<List<OrganiserEnrolmentResponse>>();
        Assert.Equal(2, list!.Count);
    }

    [Fact]
    public async Task Organiser_CannotViewEnrolmentsForAnotherOrganisersEvent()
    {
        var owner = await _factory.LoggedInClientAsync("Organiser");
        var otherOrganiser = await _factory.LoggedInClientAsync("Organiser");
        var ev = await TestSupport.CreateEventAsync(owner);

        var response = await otherOrganiser.GetAsync($"/api/events/{ev.EventID}/enrolments");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotEnrolTwiceInTheSameEvent()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        await TestSupport.EnrolAsync(participant, category.CategoryID);

        var second = await participant.PostAsync($"/api/categories/{category.CategoryID}/enrol", null);

        Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
    }

    [Fact]
    public async Task Enrol_InCategoryThatDoesNotExist_Returns404()
    {
        var participant = await _factory.LoggedInClientAsync("Participant");

        var response = await participant.PostAsync("/api/categories/999999/enrol", null);

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CanCancelOwnEnrolment_ButNotSomeoneElses()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var otherParticipant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);

        var notYours = await otherParticipant.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentID}");
        var cancel = await participant.DeleteAsync($"/api/enrolments/{enrolment.EnrolmentID}");

        Assert.Equal(HttpStatusCode.Forbidden, notYours.StatusCode);
        Assert.Equal(HttpStatusCode.NoContent, cancel.StatusCode);
    }
}