﻿using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Small helpers so each test stays short and readable.</summary>
public static class TestSupport
{
    public const string Password = "Passw0rd!";

    public static string NewEmail() => $"{Guid.NewGuid():N}@raceday.test";

    /// <summary>Creates a brand new client, registers a user with the given role, and logs them in.</summary>
    public static async Task<HttpClient> LoggedInClientAsync(this RaceDayFactory factory, string role)
    {
        var client = factory.CreateClient();
        var email = NewEmail();

        var register = await client.PostAsJsonAsync("/api/auth/register", new RegisterRequest
        {
            FullName = $"Test {role}",
            Email = email,
            Password = Password,
            PhoneNumber = "0820000000",
            Role = role
        });
        register.EnsureSuccessStatusCode();

        var login = await client.PostAsJsonAsync("/api/auth/login", new LoginRequest { Email = email, Password = Password });
        login.EnsureSuccessStatusCode();

        return client;
    }

    public static EventRequest SampleEvent(string name = "Test Fun Run") => new()
    {
        EventName = name,
        EventType = "Running",
        EventDate = DateTime.Today.AddDays(30),
        DistanceKM = 10,
        Location = "Durban, KZN",
        Latitude = -29.85868m,
        Longitude = 31.02809m,
        Description = "A test event"
    };

    public static CategoryRequest SampleCategory(string name = "10km") => new()
    {
        CategoryName = name,
        DistanceKM = 10,
        MinAge = 12,
        EntryFee = 150
    };

    public static async Task<EventResponse> CreateEventAsync(HttpClient organiser)
    {
        var response = await organiser.PostAsJsonAsync("/api/events", SampleEvent());
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EventResponse>())!;
    }

    public static async Task<CategoryResponse> CreateCategoryAsync(HttpClient organiser, int eventId)
    {
        var response = await organiser.PostAsJsonAsync($"/api/events/{eventId}/categories", SampleCategory());
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<CategoryResponse>())!;
    }

    public static async Task<EnrolmentResponse> EnrolAsync(HttpClient participant, int categoryId)
    {
        var response = await participant.PostAsync($"/api/categories/{categoryId}/enrol", null);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<EnrolmentResponse>())!;
    }
}
