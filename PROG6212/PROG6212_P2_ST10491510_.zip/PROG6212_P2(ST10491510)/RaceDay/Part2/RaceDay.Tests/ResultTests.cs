﻿using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

public class ResultTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public ResultTests(RaceDayFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task Organiser_CanRecordResult_AndParticipantCanSeeItInTheirHistory()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);

        var save = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentID}/results",
            new ResultRequest { Status = "Finished", FinishTime = new TimeSpan(0, 45, 30), Position = 3 });
        var history = await participant.GetAsync("/api/users/me/history");

        Assert.Equal(HttpStatusCode.OK, save.StatusCode);
        Assert.Equal(HttpStatusCode.OK, history.StatusCode);
        var items = await history.Content.ReadFromJsonAsync<List<HistoryResponse>>();
        var item = Assert.Single(items!);
        Assert.Equal(3, item.Position);
        Assert.Equal(new TimeSpan(0, 45, 30), item.FinishTime);
        Assert.Equal(ev.EventName, item.EventName);
    }

    [Fact]
    public async Task Results_AppearOnTheCategoryLeaderboardInPositionOrder()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var runnerOne = await _factory.LoggedInClientAsync("Participant");
        var runnerTwo = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var first = await TestSupport.EnrolAsync(runnerOne, category.CategoryID);
        var second = await TestSupport.EnrolAsync(runnerTwo, category.CategoryID);

        await organiser.PostAsJsonAsync($"/api/enrolments/{first.EnrolmentID}/results",
            new ResultRequest { Status = "Finished", FinishTime = new TimeSpan(0, 50, 0), Position = 2 });
        await organiser.PostAsJsonAsync($"/api/enrolments/{second.EnrolmentID}/results",
            new ResultRequest { Status = "Finished", FinishTime = new TimeSpan(0, 40, 0), Position = 1 });

        var response = await _factory.CreateClient().GetAsync($"/api/categories/{category.CategoryID}/results");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var board = await response.Content.ReadFromJsonAsync<List<ResultResponse>>();
        Assert.Equal(2, board!.Count);
        Assert.Equal(1, board[0].Position);
        Assert.Equal(2, board[1].Position);
    }

    [Fact]
    public async Task Organiser_CanUpdateAnExistingResult()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);
        var url = $"/api/enrolments/{enrolment.EnrolmentID}/results";

        await organiser.PostAsJsonAsync(url, new ResultRequest { Status = "Finished", FinishTime = new TimeSpan(1, 0, 0), Position = 5 });
        var update = await organiser.PostAsJsonAsync(url, new ResultRequest { Status = "Finished", FinishTime = new TimeSpan(0, 55, 0), Position = 4 });

        Assert.Equal(HttpStatusCode.OK, update.StatusCode);
        var result = await update.Content.ReadFromJsonAsync<ResultResponse>();
        Assert.Equal(4, result!.Position);
    }

    [Fact]
    public async Task FinishedResult_WithoutTimeOrPosition_Returns400()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);

        var response = await organiser.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentID}/results",
            new ResultRequest { Status = "Finished" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task AnotherOrganiser_CannotRecordResultsForSomeoneElsesEvent()
    {
        var owner = await _factory.LoggedInClientAsync("Organiser");
        var otherOrganiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(owner);
        var category = await TestSupport.CreateCategoryAsync(owner, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);

        var response = await otherOrganiser.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentID}/results",
            new ResultRequest { Status = "Finished", FinishTime = new TimeSpan(0, 40, 0), Position = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task ResultForEnrolmentThatDoesNotExist_Returns404()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");

        var response = await organiser.PostAsJsonAsync("/api/enrolments/999999/results",
            new ResultRequest { Status = "DNF" });

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Leaderboard_ForCategoryThatDoesNotExist_Returns404()
    {
        var response = await _factory.CreateClient().GetAsync("/api/categories/999999/results");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}