﻿using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

/// <summary>Proves that role-based access is enforced: the wrong role (or nobody) is rejected.</summary>
public class RoleAccessTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public RoleAccessTests(RaceDayFactory factory)
    {
        _factory = factory;
    }

    [Theory]
    [InlineData("POST", "/api/events")]
    [InlineData("PUT", "/api/events/1")]
    [InlineData("DELETE", "/api/events/1")]
    [InlineData("POST", "/api/events/1/categories")]
    [InlineData("GET", "/api/events/1/enrolments")]
    [InlineData("PUT", "/api/categories/1")]
    [InlineData("DELETE", "/api/categories/1")]
    [InlineData("POST", "/api/categories/1/route")]
    [InlineData("POST", "/api/categories/1/enrol")]
    [InlineData("DELETE", "/api/enrolments/1")]
    [InlineData("POST", "/api/enrolments/1/results")]
    [InlineData("GET", "/api/users/me")]
    [InlineData("PUT", "/api/users/me")]
    [InlineData("GET", "/api/users/me/enrolments")]
    [InlineData("GET", "/api/users/me/history")]
    public async Task ProtectedEndpoints_RejectUnauthenticatedRequests_With401(string method, string url)
    {
        var anonymous = _factory.CreateClient();

        var response = await anonymous.SendAsync(new HttpRequestMessage(new HttpMethod(method), url));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotCreateEvent()
    {
        var participant = await _factory.LoggedInClientAsync("Participant");

        var response = await participant.PostAsJsonAsync("/api/events", TestSupport.SampleEvent());

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotUpdateOrDeleteEvents()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);

        var update = await participant.PutAsJsonAsync($"/api/events/{ev.EventID}", TestSupport.SampleEvent("Nope"));
        var delete = await participant.DeleteAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.Forbidden, update.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, delete.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotManageCategoriesOrRoutes()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);

        var add = await participant.PostAsJsonAsync($"/api/events/{ev.EventID}/categories", TestSupport.SampleCategory());
        var update = await participant.PutAsJsonAsync($"/api/categories/{category.CategoryID}", TestSupport.SampleCategory("Hacked"));
        var delete = await participant.DeleteAsync($"/api/categories/{category.CategoryID}");
        var route = await participant.PostAsJsonAsync($"/api/categories/{category.CategoryID}/route", new RouteRequest
        {
            RouteName = "Nope",
            StartPoint = "A",
            EndPoint = "B"
        });

        Assert.Equal(HttpStatusCode.Forbidden, add.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, update.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, delete.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, route.StatusCode);
    }

    [Fact]
    public async Task Participant_CannotViewEventEnrolmentsOrRecordResults()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var enrolment = await TestSupport.EnrolAsync(participant, category.CategoryID);

        var viewEnrolments = await participant.GetAsync($"/api/events/{ev.EventID}/enrolments");
        var postResult = await participant.PostAsJsonAsync($"/api/enrolments/{enrolment.EnrolmentID}/results",
            new ResultRequest { Status = "Finished", FinishTime = TimeSpan.FromMinutes(40), Position = 1 });

        Assert.Equal(HttpStatusCode.Forbidden, viewEnrolments.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, postResult.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotEnrolOrViewParticipantOnlyEndpoints()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);

        var enrol = await organiser.PostAsync($"/api/categories/{category.CategoryID}/enrol", null);
        var myEnrolments = await organiser.GetAsync("/api/users/me/enrolments");
        var history = await organiser.GetAsync("/api/users/me/history");

        Assert.Equal(HttpStatusCode.Forbidden, enrol.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, myEnrolments.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, history.StatusCode);
    }

    [Fact]
    public async Task PublicEndpoints_AreAvailableWithoutLoggingIn()
    {
        var anonymous = _factory.CreateClient();

        var events = await anonymous.GetAsync("/api/events");

        Assert.Equal(HttpStatusCode.OK, events.StatusCode);
    }
}