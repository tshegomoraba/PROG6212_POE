﻿using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.Dtos;

namespace RaceDay.Tests;

public class EventTests : IClassFixture<RaceDayFactory>
{
    private readonly RaceDayFactory _factory;

    public EventTests(RaceDayFactory factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task Organiser_CanCreateEvent()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");

        var response = await organiser.PostAsJsonAsync("/api/events", TestSupport.SampleEvent("Durban 10km"));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var created = await response.Content.ReadFromJsonAsync<EventResponse>();
        Assert.Equal("Durban 10km", created!.EventName);
        Assert.Equal("Running", created.EventType);
        Assert.Equal(10, created.DistanceKM);
    }

    [Fact]
    public async Task Organiser_CanUpdateOwnEvent()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var created = await TestSupport.CreateEventAsync(organiser);
        var update = TestSupport.SampleEvent("Renamed Event");
        update.EventType = "Cycling";

        var response = await organiser.PutAsJsonAsync($"/api/events/{created.EventID}", update);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.Content.ReadFromJsonAsync<EventResponse>();
        Assert.Equal("Renamed Event", updated!.EventName);
        Assert.Equal("Cycling", updated.EventType);
    }

    [Fact]
    public async Task Organiser_CanDeleteOwnEvent()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var created = await TestSupport.CreateEventAsync(organiser);

        var delete = await organiser.DeleteAsync($"/api/events/{created.EventID}");
        var afterDelete = await organiser.GetAsync($"/api/events/{created.EventID}");

        Assert.Equal(HttpStatusCode.NoContent, delete.StatusCode);
        Assert.Equal(HttpStatusCode.NotFound, afterDelete.StatusCode);
    }

    [Fact]
    public async Task Organiser_CannotDeleteEventThatHasEnrolments()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var participant = await _factory.LoggedInClientAsync("Participant");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        await TestSupport.EnrolAsync(participant, category.CategoryID);

        var response = await organiser.DeleteAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
    }

    [Fact]
    public async Task AnotherOrganiser_CannotUpdateOrDeleteSomeoneElsesEvent()
    {
        var owner = await _factory.LoggedInClientAsync("Organiser");
        var otherOrganiser = await _factory.LoggedInClientAsync("Organiser");
        var created = await TestSupport.CreateEventAsync(owner);

        var update = await otherOrganiser.PutAsJsonAsync($"/api/events/{created.EventID}", TestSupport.SampleEvent("Hijacked"));
        var delete = await otherOrganiser.DeleteAsync($"/api/events/{created.EventID}");

        Assert.Equal(HttpStatusCode.Forbidden, update.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden, delete.StatusCode);
    }

    [Fact]
    public async Task Organiser_CanAddAndListCategories()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var ev = await TestSupport.CreateEventAsync(organiser);
        await TestSupport.CreateCategoryAsync(organiser, ev.EventID);

        var response = await _factory.CreateClient().GetAsync($"/api/events/{ev.EventID}/categories");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var categories = await response.Content.ReadFromJsonAsync<List<CategoryResponse>>();
        Assert.Single(categories!);
    }

    [Fact]
    public async Task CreateEvent_WithInvalidType_Returns400()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var request = TestSupport.SampleEvent();
        request.EventType = "Swimming";

        var response = await organiser.PostAsJsonAsync("/api/events", request);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Anyone_CanViewEventsAndTheirCategories()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var ev = await TestSupport.CreateEventAsync(organiser);
        await TestSupport.CreateCategoryAsync(organiser, ev.EventID);
        var visitor = _factory.CreateClient();

        var list = await visitor.GetAsync("/api/events");
        var single = await visitor.GetAsync($"/api/events/{ev.EventID}");

        Assert.Equal(HttpStatusCode.OK, list.StatusCode);
        Assert.Equal(HttpStatusCode.OK, single.StatusCode);
        var detail = await single.Content.ReadFromJsonAsync<EventDetailResponse>();
        Assert.Single(detail!.Categories);
    }

    [Fact]
    public async Task GetEvent_ThatDoesNotExist_Returns404()
    {
        var response = await _factory.CreateClient().GetAsync("/api/events/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Weather_ForEventThatDoesNotExist_Returns404()
    {
        var response = await _factory.CreateClient().GetAsync("/api/events/999999/weather");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Route_CanBeSavedByOrganiserAndViewedByAnyone()
    {
        var organiser = await _factory.LoggedInClientAsync("Organiser");
        var ev = await TestSupport.CreateEventAsync(organiser);
        var category = await TestSupport.CreateCategoryAsync(organiser, ev.EventID);

        var save = await organiser.PostAsJsonAsync($"/api/categories/{category.CategoryID}/route", new RouteRequest
        {
            RouteName = "Beachfront Loop",
            StartPoint = "North Beach",
            EndPoint = "uShaka",
            ElevationGainM = 40,
            MapUrl = "https://maps.example.com/loop",
            RouteNotes = "Flat and fast"
        });
        var view = await _factory.CreateClient().GetAsync($"/api/categories/{category.CategoryID}/route");

        Assert.Equal(HttpStatusCode.Created, save.StatusCode);
        Assert.Equal(HttpStatusCode.OK, view.StatusCode);
        var route = await view.Content.ReadFromJsonAsync<RouteResponse>();
        Assert.Equal("Beachfront Loop", route!.RouteName);
    }
}