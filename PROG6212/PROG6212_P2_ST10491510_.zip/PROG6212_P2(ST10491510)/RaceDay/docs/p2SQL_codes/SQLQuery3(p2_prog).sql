USE RaceDayApiDb;
SELECT * FROM Users;