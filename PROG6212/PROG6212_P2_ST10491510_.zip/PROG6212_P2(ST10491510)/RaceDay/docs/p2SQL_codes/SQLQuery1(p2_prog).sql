USE RaceDayApiDb;
SELECT * FROM Roles;